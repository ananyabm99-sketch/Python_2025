import { motion } from "framer-motion";
import StatCard from "@/components/StatCard";
import CircularProgress from "@/components/CircularProgress";
import { Activity, Flame, Heart, Moon, Droplets } from "lucide-react";
import { AreaChart, Area, ResponsiveContainer } from "recharts";

const weeklyData = [
  { day: "Mon", value: 40 },
  { day: "Tue", value: 30 },
  { day: "Wed", value: 60 },
  { day: "Thu", value: 45 },
  { day: "Fri", value: 80 },
  { day: "Sat", value: 65 },
  { day: "Sun", value: 90 },
];

export default function Dashboard() {
  return (
    <div className="p-6 pt-12 space-y-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-center"
      >
        <div>
          <h2 className="text-muted-foreground text-sm font-medium tracking-wide uppercase">Tuesday, Oct 24</h2>
          <h1 className="text-3xl font-bold text-white mt-1">Hello, Alex</h1>
        </div>
        <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-primary to-secondary p-[2px]">
          <div className="w-full h-full rounded-full bg-background overflow-hidden border-2 border-background">
            <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Alex" alt="Avatar" className="w-full h-full object-cover" />
          </div>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="bg-gradient-to-br from-primary/20 to-secondary/20 border border-white/10 rounded-3xl p-6 relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-white/5 backdrop-blur-sm" />
        <div className="relative z-10 flex items-center justify-between">
          <div>
            <h3 className="text-white/80 font-medium mb-1">Daily Goal</h3>
            <div className="text-4xl font-bold text-white mb-2">8,432 <span className="text-lg font-normal text-white/60">/ 10k steps</span></div>
            <p className="text-sm text-primary font-medium flex items-center gap-1">
              <Flame size={16} /> 487 kcal burned
            </p>
          </div>
          <CircularProgress value={8432} max={10000} size={100} strokeWidth={8} color="hsl(var(--primary))" delay={0.2} />
        </div>
      </motion.div>

      <div className="grid grid-cols-2 gap-4">
        <StatCard
          title="Heart Rate"
          value="72"
          subtitle="bpm"
          icon={<Heart size={18} className="text-destructive" />}
          trend="+2%"
          trendUp={false}
          delay={0.2}
          className="bg-destructive/5"
        />
        <StatCard
          title="Sleep"
          value="7h 15m"
          subtitle="Quality: 87%"
          icon={<Moon size={18} className="text-secondary" />}
          trend="Good"
          trendUp={true}
          delay={0.3}
          className="bg-secondary/5"
        />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5"
      >
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Droplets size={18} className="text-blue-400" />
            <span className="font-medium text-sm tracking-wide uppercase">Water Intake</span>
          </div>
          <span className="text-white font-bold">6/8 Glasses</span>
        </div>
        <div className="flex gap-2">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((glass) => (
            <motion.div
              key={glass}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.4 + glass * 0.05 }}
              className={`h-12 flex-1 rounded-lg ${glass <= 6 ? 'bg-blue-400/80 shadow-[0_0_10px_rgba(96,165,250,0.5)]' : 'bg-white/10'}`}
            />
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 h-48 flex flex-col"
      >
        <h3 className="font-medium text-sm tracking-wide uppercase text-muted-foreground mb-4">Weekly Activity</h3>
        <div className="flex-1 w-full relative">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={weeklyData}>
              <defs>
                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <Area type="monotone" dataKey="value" stroke="hsl(var(--primary))" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </div>
  );
}
