import { motion } from "framer-motion";
import { Settings, Award, Edit3, Flame, Droplets, Moon, Activity } from "lucide-react";
import StatCard from "@/components/StatCard";

export default function Profile() {
  return (
    <div className="p-6 pt-12 space-y-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-white">Profile</h1>
        <button className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white/10 transition-colors" data-testid="btn-settings">
          <Settings size={20} />
        </button>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-40 h-40 bg-primary/20 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
        
        <div className="flex items-center gap-6 relative z-10">
          <div className="relative">
            <div className="w-24 h-24 rounded-full border-2 border-primary/50 overflow-hidden bg-background">
              <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Alex" alt="Alex Johnson" className="w-full h-full object-cover" />
            </div>
            <div className="absolute bottom-0 right-0 w-8 h-8 bg-primary rounded-full border-2 border-background flex items-center justify-center">
              <Edit3 size={14} className="text-background" />
            </div>
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Alex Johnson</h2>
            <p className="text-primary font-medium">28 years old</p>
            <p className="text-muted-foreground text-sm mt-1">San Francisco, CA</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mt-8 pt-6 border-t border-white/10 relative z-10">
          <div className="text-center">
            <div className="text-2xl font-bold text-white">74</div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground mt-1">kg</div>
          </div>
          <div className="text-center border-x border-white/10">
            <div className="text-2xl font-bold text-white">182</div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground mt-1">cm</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white">22.3</div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground mt-1">BMI</div>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <h3 className="font-medium text-sm tracking-wide uppercase text-muted-foreground mb-4 pl-2">Current Goals</h3>
        <div className="space-y-3">
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-white font-medium flex items-center gap-2"><Flame size={16} className="text-primary"/> Weight Loss</span>
              <span className="text-primary">70%</span>
            </div>
            <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
              <div className="h-full bg-primary w-[70%]" />
            </div>
            <p className="text-xs text-white/50 mt-2 text-right">74kg → 70kg</p>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-white font-medium flex items-center gap-2"><Activity size={16} className="text-chart-3"/> Running Distance</span>
              <span className="text-chart-3">45%</span>
            </div>
            <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
              <div className="h-full bg-chart-3 w-[45%]" />
            </div>
            <p className="text-xs text-white/50 mt-2 text-right">9km / 20km this week</p>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <h3 className="font-medium text-sm tracking-wide uppercase text-muted-foreground mb-4 pl-2">Achievements</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gradient-to-br from-yellow-500/20 to-orange-600/20 border border-yellow-500/30 rounded-2xl p-4 flex flex-col items-center text-center">
            <Award size={32} className="text-yellow-400 mb-2" />
            <h4 className="text-white font-bold mb-1">7-Day Streak</h4>
            <p className="text-xs text-white/70">Activity ring closed</p>
          </div>
          <div className="bg-gradient-to-br from-secondary/20 to-purple-600/20 border border-secondary/30 rounded-2xl p-4 flex flex-col items-center text-center">
            <Moon size={32} className="text-secondary mb-2" />
            <h4 className="text-white font-bold mb-1">Sleep Champ</h4>
            <p className="text-xs text-white/70">8h average this week</p>
          </div>
        </div>
      </motion.div>
      
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="w-full py-4 rounded-xl bg-white/5 text-destructive font-medium border border-destructive/20 mt-4 hover:bg-destructive/10 transition-colors"
        data-testid="btn-logout"
      >
        Sign Out
      </motion.button>
    </div>
  );
}
