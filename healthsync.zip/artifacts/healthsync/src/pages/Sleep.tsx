import { motion } from "framer-motion";
import { Moon, Sunrise, Sunset, Activity } from "lucide-react";
import { AreaChart, Area, ResponsiveContainer, XAxis } from "recharts";
import StatCard from "@/components/StatCard";
import CircularProgress from "@/components/CircularProgress";

const sleepPhases = [
  { time: "22:30", phase: 3 }, // Awake
  { time: "23:00", phase: 1 }, // Deep
  { time: "00:00", phase: 2 }, // Light
  { time: "01:30", phase: 1 }, // Deep
  { time: "03:00", phase: 2 }, // Light
  { time: "04:30", phase: 3 }, // REM
  { time: "05:30", phase: 2 }, // Light
  { time: "06:45", phase: 3 }, // Awake
];

export default function Sleep() {
  return (
    <div className="p-6 pt-12 space-y-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-3xl font-bold text-white mb-2">Sleep</h1>
        <p className="text-muted-foreground">Rest and recovery</p>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="bg-gradient-to-br from-secondary/20 to-blue-900/40 border border-secondary/20 rounded-3xl p-8 relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-white/5 backdrop-blur-sm" />
        <div className="relative z-10 flex flex-col items-center">
          <div className="flex items-center gap-2 text-secondary mb-6 bg-secondary/10 px-4 py-2 rounded-full border border-secondary/20">
            <Moon size={16} className="fill-secondary" />
            <span className="font-semibold text-sm">Sleep Score: 87%</span>
          </div>
          
          <CircularProgress 
            value={7.25} 
            max={8} 
            size={160} 
            strokeWidth={12} 
            color="hsl(var(--secondary))" 
            label="Hours"
            delay={0.2}
          />
          
          <div className="mt-8 grid grid-cols-2 gap-8 w-full border-t border-white/10 pt-6">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-white/50 text-xs uppercase tracking-wider mb-1">
                <Sunset size={14} /> Bedtime
              </div>
              <div className="text-xl font-bold text-white">10:30 PM</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 text-white/50 text-xs uppercase tracking-wider mb-1">
                <Sunrise size={14} /> Wake
              </div>
              <div className="text-xl font-bold text-white">6:45 AM</div>
            </div>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 gap-4">
        <StatCard
          title="Deep Sleep"
          value="2h 15m"
          subtitle="28% of total"
          icon={<Activity size={18} className="text-indigo-400" />}
          delay={0.3}
        />
        <StatCard
          title="REM Sleep"
          value="1h 45m"
          subtitle="21% of total"
          icon={<Activity size={18} className="text-secondary" />}
          delay={0.4}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5"
      >
        <h3 className="font-medium text-sm tracking-wide uppercase text-muted-foreground mb-6">Sleep Phases</h3>
        <div className="h-48 w-full relative">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={sleepPhases} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorPhase" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--secondary))" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="hsl(var(--secondary))" stopOpacity={0.1}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 12 }} />
              <Area type="stepAfter" dataKey="phase" stroke="hsl(var(--secondary))" strokeWidth={3} fillOpacity={1} fill="url(#colorPhase)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </div>
  );
}
