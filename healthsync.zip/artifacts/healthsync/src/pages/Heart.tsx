import { motion } from "framer-motion";
import { Heart as HeartIcon, AlertCircle, Activity } from "lucide-react";
import { LineChart, Line, ResponsiveContainer } from "recharts";
import StatCard from "@/components/StatCard";

const heartRateData = Array.from({ length: 24 }).map((_, i) => ({
  time: `${i}:00`,
  bpm: 60 + Math.random() * 30 + (i > 8 && i < 20 ? 10 : 0)
}));

export default function Heart() {
  return (
    <div className="p-6 pt-12 space-y-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-3xl font-bold text-white mb-2">Heart</h1>
        <p className="text-muted-foreground">Real-time monitoring</p>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="bg-gradient-to-b from-destructive/20 to-background border border-destructive/20 rounded-3xl p-8 flex flex-col items-center justify-center relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,107,107,0.2)_0%,transparent_70%)]" />
        
        <div className="relative mb-6">
          <motion.div
            animate={{ scale: [1, 1.15, 1] }}
            transition={{ duration: 0.8, repeat: Infinity, ease: "easeInOut" }}
            className="absolute inset-0 bg-destructive/30 rounded-full blur-xl"
          />
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 0.8, repeat: Infinity, ease: "easeInOut" }}
          >
            <HeartIcon size={80} className="text-destructive fill-destructive" />
          </motion.div>
        </div>
        
        <div className="text-center relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-7xl font-black text-white tracking-tighter flex items-end justify-center gap-2"
          >
            72 <span className="text-2xl font-bold text-destructive pb-2">BPM</span>
          </motion.div>
          <p className="text-white/60 font-medium mt-2">Resting Heart Rate</p>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 gap-4">
        <StatCard
          title="High"
          value="115"
          subtitle="bpm"
          icon={<Activity size={18} className="text-orange-400" />}
          delay={0.2}
        />
        <StatCard
          title="Low"
          value="58"
          subtitle="bpm"
          icon={<Activity size={18} className="text-blue-400" />}
          delay={0.3}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5"
      >
        <h3 className="font-medium text-sm tracking-wide uppercase text-muted-foreground mb-4">Today's Range</h3>
        <div className="h-40 w-full relative -ml-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={heartRateData}>
              <Line 
                type="monotone" 
                dataKey="bpm" 
                stroke="hsl(var(--destructive))" 
                strokeWidth={3} 
                dot={false}
                activeDot={{ r: 6, fill: "hsl(var(--destructive))", stroke: "white" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-destructive/10 border border-destructive/30 rounded-2xl p-5 flex items-start gap-4"
      >
        <div className="bg-destructive/20 p-2 rounded-full text-destructive mt-1">
          <AlertCircle size={20} />
        </div>
        <div>
          <h4 className="text-white font-semibold mb-1">Normal Rhythm</h4>
          <p className="text-white/70 text-sm">Your heart rhythm shows no signs of irregular patterns. Keep maintaining your healthy lifestyle.</p>
        </div>
      </motion.div>
    </div>
  );
}
