import { motion } from "framer-motion";
import { Activity as ActivityIcon, MapPin, TrendingUp, Zap } from "lucide-react";
import { BarChart, Bar, ResponsiveContainer, Cell, XAxis } from "recharts";
import StatCard from "@/components/StatCard";

const weeklySteps = [
  { day: "M", steps: 6000 },
  { day: "T", steps: 8432 },
  { day: "W", steps: 10200 },
  { day: "T", steps: 7500 },
  { day: "F", steps: 9000 },
  { day: "S", steps: 12000 },
  { day: "S", steps: 11000 },
];

export default function Activity() {
  return (
    <div className="p-6 pt-12 space-y-6">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-3xl font-bold text-white mb-2">Activity</h1>
        <p className="text-muted-foreground">You're doing great today.</p>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="relative bg-gradient-to-br from-chart-3/20 to-primary/20 border border-white/10 rounded-3xl p-8 flex flex-col items-center justify-center"
      >
        <ActivityIcon size={32} className="text-chart-3 mb-4" />
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-6xl font-black text-white tracking-tighter"
        >
          8,432
        </motion.div>
        <span className="text-lg text-chart-3 font-medium mt-1 uppercase tracking-widest">Steps</span>
        
        <div className="mt-8 w-full">
          <div className="flex justify-between text-sm text-white/60 mb-2">
            <span>Progress</span>
            <span>84%</span>
          </div>
          <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: "84%" }}
              transition={{ duration: 1, delay: 0.5, ease: "easeOut" }}
              className="h-full bg-chart-3"
            />
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 gap-4">
        <StatCard
          title="Distance"
          value="2.1"
          subtitle="km"
          icon={<MapPin size={18} className="text-blue-400" />}
          delay={0.2}
        />
        <StatCard
          title="Active Energy"
          value="487"
          subtitle="kcal"
          icon={<Zap size={18} className="text-yellow-400" />}
          delay={0.3}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5"
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-medium text-sm tracking-wide uppercase text-muted-foreground flex items-center gap-2">
            <TrendingUp size={16} /> Weekly Steps
          </h3>
        </div>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={weeklySteps}>
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 12 }} dy={10} />
              <Bar dataKey="steps" radius={[4, 4, 4, 4]} animationDuration={1500}>
                {weeklySteps.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.steps > 10000 ? 'hsl(var(--chart-3))' : 'hsl(var(--primary))'} fillOpacity={entry.steps === 8432 ? 1 : 0.5} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </div>
  );
}
