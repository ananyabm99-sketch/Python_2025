import { motion } from "framer-motion";
import { ReactNode } from "react";

interface StatCardProps {
  title: string;
  value: string | ReactNode;
  subtitle?: string;
  icon?: ReactNode;
  trend?: string;
  trendUp?: boolean;
  className?: string;
  delay?: number;
  testId?: string;
}

export default function StatCard({
  title,
  value,
  subtitle,
  icon,
  trend,
  trendUp,
  className = "",
  delay = 0,
  testId
}: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className={`bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-5 relative overflow-hidden ${className}`}
      data-testid={testId || `stat-card-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none" />
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-2 text-muted-foreground">
          {icon}
          <span className="font-medium text-sm tracking-wide uppercase">{title}</span>
        </div>
        {trend && (
          <div className={`text-xs font-semibold px-2 py-1 rounded-full ${trendUp ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
            {trend}
          </div>
        )}
      </div>
      <div className="flex flex-col">
        <span className="text-3xl font-bold text-white tracking-tight">{value}</span>
        {subtitle && <span className="text-sm text-muted-foreground mt-1">{subtitle}</span>}
      </div>
    </motion.div>
  );
}
