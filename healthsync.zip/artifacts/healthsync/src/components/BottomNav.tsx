import { Link, useLocation } from "wouter";
import { Home, Activity, Heart, Moon, User } from "lucide-react";
import { motion } from "framer-motion";

export default function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/activity", icon: Activity, label: "Activity" },
    { path: "/heart", icon: Heart, label: "Heart" },
    { path: "/sleep", icon: Moon, label: "Sleep" },
    { path: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 w-full max-w-[430px] mx-auto bg-card/80 backdrop-blur-xl border-t border-white/10 pb-safe pt-2 px-6 z-50">
      <div className="flex justify-between items-center h-16">
        {navItems.map((item) => {
          const isActive = location === item.path;
          const Icon = item.icon;
          return (
            <Link key={item.path} href={item.path} className="relative flex flex-col items-center justify-center w-12 h-12" data-testid={`nav-${item.label.toLowerCase()}`}>
              <motion.div
                initial={false}
                animate={{
                  color: isActive ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))",
                  y: isActive ? -2 : 0,
                }}
                className="relative z-10"
              >
                <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
              </motion.div>
              {isActive && (
                <motion.div
                  layoutId="bottom-nav-indicator"
                  className="absolute inset-0 bg-primary/20 rounded-full blur-md z-0"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              <motion.span
                initial={false}
                animate={{
                  opacity: isActive ? 1 : 0,
                  y: isActive ? 4 : 10,
                }}
                className="text-[10px] font-medium text-primary mt-1"
              >
                {item.label}
              </motion.span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
