import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/Dashboard";
import Activity from "@/pages/Activity";
import Heart from "@/pages/Heart";
import Sleep from "@/pages/Sleep";
import Profile from "@/pages/Profile";
import BottomNav from "@/components/BottomNav";

const queryClient = new QueryClient();

function Router() {
  return (
    <div className="min-h-[100dvh] w-full max-w-[430px] mx-auto relative pb-20 bg-background text-foreground overflow-x-hidden">
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/activity" component={Activity} />
        <Route path="/heart" component={Heart} />
        <Route path="/sleep" component={Sleep} />
        <Route path="/profile" component={Profile} />
      </Switch>
      <BottomNav />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
